var admin = require("./admin");
var users = require("./users");
var account = require("./account");
var weight = require("./weight");
var home = require("./home");

module.exports = { admin, users, account, weight, home };
